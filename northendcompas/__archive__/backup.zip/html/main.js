// JavaScript code goes here

function myFunction() {
  document.querySelector("#replace").innerHTML = "Hello World!";
}